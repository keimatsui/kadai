//  VideoCameraViewController.h

#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>

@interface VideoCameraViewController : UIViewController 
        <AVCaptureVideoDataOutputSampleBufferDelegate>
{
    AVCaptureSession*   _session;
    
    IBOutlet UIImageView*   _imageView;
}

@end
