//
//  VideoCameraAppDelegate.h
//  VideoCamera
//
//  Created by Makoto Kinoshita on 11/06/08.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class VideoCameraViewController;

@interface VideoCameraAppDelegate : NSObject <UIApplicationDelegate> {

}

@property (nonatomic, retain) IBOutlet UIWindow *window;

@property (nonatomic, retain) IBOutlet VideoCameraViewController *viewController;

@end
